# Green Campus — demo dự án môi trường

Đây là trang demo tĩnh cho ý tưởng dự án học tập về quản lý rác thải nhựa trong khuôn viên trường đại học.

## Chạy thử
Mở `index.html` bằng trình duyệt.

## Đưa lên GitHub Pages
1. Đăng nhập GitHub và tạo repository mới, ví dụ `green-campus-demo`.
2. Tải `index.html` và `README.md` lên repository.
3. Vào **Settings → Pages**.
4. Ở phần Build and deployment, chọn **Deploy from a branch**, branch `main`, folder `/ (root)`, rồi Save.
5. Đợi GitHub Pages triển khai. URL thường có dạng `https://TEN-TAI-KHOAN.github.io/green-campus-demo/`.

## Lưu ý
Các nội dung và thanh quy trình là minh họa giao diện; không phải số liệu hoặc thành tích khảo sát thực tế. Hãy thay bằng dữ liệu có thật trước khi đưa vào hồ sơ ứng tuyển.
